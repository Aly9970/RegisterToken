package com.register.contoller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.register.dtos.SignUp;
import com.register.dtos.UserDTO;
import com.register.service.Authentication;

@RestController
public class SignupController {
@Autowired
private Authentication Authen;
@PostMapping("/register")
public ResponseEntity<?> createUser(@RequestBody SignUp signup){
	UserDTO createUser=Authen.createuser(signup);
	if(createUser == null) {
		return new ResponseEntity<>("User is not Created ,try again later.",HttpStatus.BAD_REQUEST);}
		return new ResponseEntity<>(createUser,HttpStatus.CREATED);


}
}
