package com.register.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.register.Entities.User;
import com.register.dtos.SignUp;
import com.register.dtos.UserDTO;
import com.register.repository.UserRespo;
@Service
public class AuthenticImpl implements Authentication{
@Autowired
private UserRespo userRespo;

@Override
public UserDTO createuser(SignUp signup) {
	User user=new User();
	user.setEmail(signup.getEmail());
	user.setPhone(signup.getPhone());
	user.setPassword(new BCryptPasswordEncoder().encode(signup.getPassword()));
	user.setUsername(signup.getName());
	User createdUser=userRespo.save(user);
	UserDTO userDTO=new UserDTO();
	userDTO.setEmail(signup.getEmail());
	userDTO.setName(signup.getName());
	userDTO.setPhone(signup.getPhone());
	
	return userDTO;
}
}
