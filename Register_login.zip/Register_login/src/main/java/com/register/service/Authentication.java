package com.register.service;

import org.springframework.stereotype.Service;

import com.register.dtos.SignUp;
import com.register.dtos.UserDTO;

@Service
public interface Authentication {
UserDTO createuser(SignUp signup);
}
